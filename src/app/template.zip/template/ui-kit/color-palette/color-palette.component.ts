import { Component } from '@angular/core';

@Component({
    selector: 'app-colorPalette',
    templateUrl: './color-palette.component.html',
    styleUrls: ['./color-palette.component.scss']
})

export class ColorPaletteComponent {

}