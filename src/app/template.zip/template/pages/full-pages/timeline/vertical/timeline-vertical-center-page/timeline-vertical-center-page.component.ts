import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timeline-vertical-center-page',
  templateUrl: './timeline-vertical-center-page.component.html',
  styleUrls: ['./timeline-vertical-center-page.component.scss']
})
export class TimelineVerticalCenterPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
