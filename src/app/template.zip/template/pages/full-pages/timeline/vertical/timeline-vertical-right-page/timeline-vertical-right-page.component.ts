import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timeline-vertical-right-page',
  templateUrl: './timeline-vertical-right-page.component.html',
  styleUrls: ['./timeline-vertical-right-page.component.scss']
})
export class TimelineVerticalRightPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
