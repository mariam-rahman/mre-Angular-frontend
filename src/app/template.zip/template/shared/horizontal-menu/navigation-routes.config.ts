import { RouteInfo } from "../vertical-menu/vertical-menu.metadata";

export const HROUTES: RouteInfo[] = [
  { path: '/', title: 'Dashboard', icon: 'ft-bar-chart-2', role: 'TAQNIN_DASHBOARD_MODULE', class: 'dropdown nav-item ', isExternalLink: false, submenu: [] },
  { path: '/packages', title: 'Packages', icon: 'ft-package', role: '', class: 'dropdown nav-item ', isExternalLink: false, submenu: [] },
  { path: '/clients', title: 'Clients', icon: 'ft-user', role: '', class: 'dropdown nav-item', isExternalLink: false, submenu: [] },
  { path: '/subscriptions', title: 'Subscriptions', icon: 'ft-check-square', role: '', class: 'dropdown nav-item', isExternalLink: false, submenu: [] },
  { path: '/gifts', title: 'Gifts', icon: 'ft-gift', role: '', class: 'dropdown nav-item', isExternalLink: false, submenu: [] },
  { path: '/redeems', title: 'Redeems', icon: 'ft-command', role: '', class: 'dropdown nav-item ', isExternalLink: false, submenu: [] },
  { path: '/message', title: 'Messages', icon: 'ft-message-square', role: '', class: 'dropdown nav-item ', isExternalLink: false, submenu: []}, 

  {
      path: '', title: 'Settings', icon: 'ft ft-settings', role: '', class: 'dropdown nav-item has-sub', isExternalLink: false,
      submenu: [
        { path: '/admin/users', title: 'User', icon: 'ft-arrow-right submenu-icon', role: '', class: 'dropdown-item', isExternalLink: false, submenu: [] },
        { path: '/admin/groups', title: 'Group', icon: 'ft-arrow-right submenu-icon', role: '', class: 'dropdown-item', isExternalLink: false, submenu: [] },
        { path: '/admin/roles', title: 'Role', icon: 'ft-arrow-right submenu-icon', role: '', class: 'dropdown-item', isExternalLink: false, submenu: [] },
        { path: '/admin/permissions', title: 'Permission', icon: 'ft-arrow-right submenu-icon', role: '', class: 'dropdown-item', isExternalLink: false, submenu: [] },
      ]
  },



];
