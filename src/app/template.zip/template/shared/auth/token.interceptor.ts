import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { AuthService } from './auth.service';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {

  constructor(public auth: AuthService) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    request = request.clone({
      setHeaders: {
        Authorization: `Bearer eyJ4NXQiOiJNell4TW1Ga09HWXdNV0kwWldObU5EY3hOR1l3WW1NNFpUQTNNV0kyTkRBelpHUXpOR00wWkdSbE5qSmtPREZrWkRSaU9URmtNV0ZoTXpVMlpHVmxOZyIsImtpZCI6Ik16WXhNbUZrT0dZd01XSTBaV05tTkRjeE5HWXdZbU00WlRBM01XSTJOREF6WkdRek5HTTBaR1JsTmpKa09ERmtaRFJpT1RGa01XRmhNelUyWkdWbE5nX1JTMjU2IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJhZG1pbiIsImF1dCI6IkFQUExJQ0FUSU9OIiwiYXVkIjoibUQ4Mk1xY0lXVnB2aTZHRVlwRmtISkV2UWMwYSIsIm5iZiI6MTY0Mzc0Nzk4MiwiYXpwIjoibUQ4Mk1xY0lXVnB2aTZHRVlwRmtISkV2UWMwYSIsInNjb3BlIjoiZGVmYXVsdCIsImlzcyI6Imh0dHBzOlwvXC9sb2NhbGhvc3Q6OTQ0M1wvb2F1dGgyXC90b2tlbiIsImV4cCI6MTY0Mzc1MTU4MiwiaWF0IjoxNjQzNzQ3OTgyLCJqdGkiOiI3ZTFjZDg1Yi1mNjdjLTQ0NzItOWI5My1hMDg2NzE2ZTZiNDEifQ.K5Sx5bYLucrfwybVFeZn72LMLWLepxo9Uqabj1aGQyqZtApPP6RbVRfV6MUbWudD-ED4B3DBfbQBxUUW2Y_eMWrudEz-k9ex1ra2x2vQIe5CnXOlsDTZMCZ6T9RjH4011nU_cyW86r_yKJjklDbPUeh2JVrE_MjFzwWnnZ9KSfje7CiQ1FD9xswll57N2eBN8SDvnm7sieSoI8R_6rnnG1kb8U2K5o3zShr-KWsETz_WN5k4g0NZb3IowQX71YVqycdoR9b_s2aa00dXL2PRijrHZcTwbDuyre74a3nBUgBd5U5rs8TAOBMG4HcDUbMUwOY_1bvr53tgrl0JeScy7A`
      }
    });

    return next.handle(request);
  }
}